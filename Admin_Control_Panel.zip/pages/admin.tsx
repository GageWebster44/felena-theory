import { useEffect, useState } from 'react';
import { supabase } from '../utils/supabaseClient';

export default function AdminPanel() {
  const [operators, setOperators] = useState([]);
  const [xp, setXp] = useState(100);
  const [log, setLog] = useState([]);

  const fetchOperators = async () => {
    const { data } = await supabase.from('operators').select('id, alias, xp');
    setOperators(data || []);
  };

  const injectXP = async (id) => {
    await supabase.from('operators').update({ xp: xp }).eq('id', id);
    await supabase.from('xp_transactions').insert({
      operator_id: id,
      type: 'inject',
      amount: xp
    });
    fetchOperators();
  };

  const unlockCRT = async (id, route) => {
    await supabase.from('crt_unlocks').upsert({
      operator_id: id,
      route: route,
      unlocked: true,
      unlocked_at: new Date().toISOString()
    });
  };

  const fetchLogs = async () => {
    const { data } = await supabase.from('override_logs').select('*').order('created_at', { ascending: false }).limit(25);
    setLog(data || []);
  };

  useEffect(() => {
    fetchOperators();
    fetchLogs();
  }, []);

  return (
    <div style={{ padding: '2rem', background: '#000', color: '#0f0', fontFamily: 'monospace' }}>
      <h1>🛠 Admin Control Panel</h1>

      <h2>Inject XP</h2>
      <input type="number" value={xp} onChange={(e) => setXp(Number(e.target.value))} />
      {operators.map((op) => (
        <div key={op.id}>
          {op.alias} — Current XP: {op.xp}
          <button onClick={() => injectXP(op.id)}>Inject XP</button>
          <button onClick={() => unlockCRT(op.id, '/simulator')}>Unlock Simulator</button>
        </div>
      ))}

      <h2 style={{ marginTop: '2rem' }}>Recent Override Logs</h2>
      <div style={{ maxHeight: '200px', overflowY: 'scroll', background: '#111', padding: '1rem' }}>
        {log.map((entry) => (
          <div key={entry.id}>
            [{entry.created_at}] {entry.operator_id} — {entry.action} → {entry.target}
          </div>
        ))}
      </div>
    </div>
  );
}
