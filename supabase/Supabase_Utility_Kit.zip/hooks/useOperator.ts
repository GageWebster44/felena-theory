import { useContext } from 'react';
import { OperatorContext } from '../context/OperatorContext';

export const useOperator = () => useContext(OperatorContext);
