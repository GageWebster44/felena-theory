import { supabase } from './supabaseClient';

export const activateEngine = async (operatorId: string, engineId: string) => {
  await supabase
    .from('engine_unlocks')
    .update({ activated: true, last_activated: new Date().toISOString() })
    .eq('operator_id', operatorId)
    .eq('engine_id', engineId);
};
