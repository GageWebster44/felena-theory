import { supabase } from './supabaseClient';

export const hasCRTAccess = async (operatorId: string, route: string) => {
  const { data } = await supabase
    .from('crt_unlocks')
    .select('unlocked')
    .eq('operator_id', operatorId)
    .eq('route', route)
    .single();
  return data?.unlocked ?? false;
};
