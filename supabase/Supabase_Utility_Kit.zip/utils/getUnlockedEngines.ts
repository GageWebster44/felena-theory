import { supabase } from './supabaseClient';

export const getUnlockedEngines = async (operatorId: string) => {
  const { data } = await supabase
    .from('engine_unlocks')
    .select('*')
    .eq('operator_id', operatorId)
    .eq('unlocked', true);
  return data;
};
