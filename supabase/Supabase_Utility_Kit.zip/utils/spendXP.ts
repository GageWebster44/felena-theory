import { supabase } from './supabaseClient';

export const spendXP = async (operatorId: string, amount: number, reason: string) => {
  const { data: operator } = await supabase
    .from('operators')
    .select('xp')
    .eq('id', operatorId)
    .single();

  if (!operator || operator.xp < amount) return false;

  await supabase
    .from('operators')
    .update({ xp: operator.xp - amount })
    .eq('id', operatorId);

  await supabase
    .from('xp_transactions')
    .insert({ operator_id: operatorId, type: reason, amount: -amount });

  return true;
};
