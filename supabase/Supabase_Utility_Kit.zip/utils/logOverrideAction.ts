import { supabase } from './supabaseClient';

export const logOverrideAction = async (
  operatorId: string,
  action: string,
  target: string,
  metadata = {}
) => {
  await supabase
    .from('override_logs')
    .insert({ operator_id: operatorId, action, target, metadata });
};
